#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_AHT10.h>
#include <BH1750.h>
#include <SPI.h>
#include <SD.h>
#include <WiFi.h>
#include "time.h"

// --- CONFIGURACIÓN WIFI ---
const char* ssid     = "DIGIFIBRA-19F2";
const char* password = "BJ77YR7NY7";

// --- CONFIGURACIÓN TIEMPO (NTP) ---
const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 3600;      
const int   daylightOffset_sec = 3600; 

bool modoSD = true; 

// --- PINES ESP32-S3 ---
#define I2C_SDA   8
#define I2C_SCL   9
#define SD_CS     10
#define PIN_POT   4
#define PIN_LED   5

// --- INSTANCIAS ---
Adafruit_SSD1306 display(128, 64, &Wire, -1);
Adafruit_AHT10 aht;
BH1750 lightMeter;

unsigned long ultimaEscritura = 0;
const long intervaloLog = 10000; // Volcado cada 10 segundos

void setup() {
  Serial.begin(115200);
  
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setClock(100000); 

  // 1. Iniciar OLED
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println("OLED no encontrado");
    for(;;); 
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0,0);
  display.println("Iniciando...");
  display.display();

  // 2. Conectar WiFi y Sincronizar Hora
  WiFi.disconnect(true); 
  delay(1000);           
  WiFi.mode(WIFI_STA);   
  WiFi.begin(ssid, password);
  display.print("Conectando WiFi");
  display.display();
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    display.print(".");
    display.display();
  }
  
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
    display.println("\nError Hora");
  } else {
    display.println("\nHora OK!");
  }
  display.display();
  delay(1000);

  // 3. Iniciar Sensores
  if (!aht.begin()) Serial.println("Error AHT10");
  if (!lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE, 0x23)) Serial.println("Error BH1750");

  // 4. Iniciar MicroSD
  if (modoSD) {
    if (!SD.begin(SD_CS)) {
      display.println("Error SD!");
      display.display();
    } else {
      if (!SD.exists("/log.csv")) {
        File file = SD.open("/log.csv", FILE_WRITE);
        file.println("Fecha_Hora;Temp_C;Hum_H;Luz_Lux;Umbral_Lux;Alarma_Activa");
        file.close();
      }
    }
  }
}

void loop() {
  // --- Leer Sensores ---
  sensors_event_t humidity, temp;
  aht.getEvent(&humidity, &temp);
  
  float t = temp.temperature;
  float h = humidity.relative_humidity;
  float lux = lightMeter.readLightLevel();

  // --- Leer Potenciómetro y calcular Umbral ---
  int lecturaPot = analogRead(PIN_POT);
  // Mapeamos de 0-4095 (12 bits) a un rango de 0 a 2000 Lux
  float umbralLux = map(lecturaPot, 0, 4095, 0, 2000);

  // --- Lógica de Alarma ---
  bool alarmaEncendida = false;
  if (lux >= 0 && lux > umbralLux) {
    digitalWrite(PIN_LED, HIGH);
    alarmaEncendida = true;
  } else {
    digitalWrite(PIN_LED, LOW);
  }

  // --- Mostrar en OLED ---
  actualizarOLED(t, h, lux, umbralLux, alarmaEncendida);

  // --- Volcado a SD ---
  if (modoSD && (millis() - ultimaEscritura >= intervaloLog)) {
    ultimaEscritura += intervaloLog; 
    guardarEnSD(t, h, lux, umbralLux, alarmaEncendida);
  }

  delay(200);
}

void actualizarOLED(float t, float h, float l, float umbral, bool alarma) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  
  // Mostrar hora
  struct tm timeinfo;
  if(getLocalTime(&timeinfo)){
    display.setCursor(0,0);
    display.printf("%02d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
  }

  // Indicador de ALARMA
  if (alarma) {
    display.setCursor(85, 0);
    display.print("ALERTA");
  }

  display.drawFastHLine(0, 11, 128, WHITE);

  // Mostrar datos
  display.setCursor(0, 18);
  display.printf("Temp: %.1f C Hum: %.0f%%", t, h);
  
  display.setCursor(0, 34);
  if (l < 0) display.printf("Luz: ERROR");
  else       display.printf("Luz: %.0f lx", l);
  
  display.setCursor(0, 50);
  display.printf("Umbral: %.0f lx", umbral);
  
  display.display();
}

void guardarEnSD(float t, float h, float l, float umbral, bool alarma) {
  struct tm timeinfo;
  String timestamp = "00-00-00 00:00:00";
  
  if(getLocalTime(&timeinfo)){
    char buffer[25];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &timeinfo);
    timestamp = String(buffer);
  }

  File dataFile = SD.open("/log.csv", FILE_APPEND);
  if (dataFile) {
    String tStr = String(t, 1); tStr.replace(".", ",");
    String hStr = String(h, 0); hStr.replace(".", ",");
    String lStr = String(l, 0); lStr.replace(".", ",");
    String uStr = String(umbral, 0); uStr.replace(".", ",");
    String alrmStr = alarma ? "SI" : "NO";

    dataFile.printf("%s;%s;%s;%s;%s;%s\n", timestamp.c_str(), tStr.c_str(), hStr.c_str(), lStr.c_str(), uStr.c_str(), alrmStr.c_str());
    dataFile.close();
    Serial.println("Dato guardado en SD");
  } else {
    Serial.println("Error abriendo log.csv");
  }
}